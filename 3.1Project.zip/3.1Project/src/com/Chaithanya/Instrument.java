package com.Chaithanya;

public abstract class Instrument {
	public abstract void play1();

	public void play() {
		// TODO Auto-generated method stub
		
	}
}