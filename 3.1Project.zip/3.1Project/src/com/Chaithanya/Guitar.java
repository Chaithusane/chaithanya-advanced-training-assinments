package com.Chaithanya;

public class Guitar extends Instrument {

	public void play() {
		System.out.println("Guitar is playing  tin  tin  tin");

	}

	@Override
	public void play1() {
		// TODO Auto-generated method stub
		
	}

}