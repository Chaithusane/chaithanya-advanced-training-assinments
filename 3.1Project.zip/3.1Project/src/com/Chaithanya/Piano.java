package com.Chaithanya;


public class Piano extends Instrument {

	public void play() {
		System.out.println("Piano is playing  tan tan tan tan");

	}

	@Override
	public void play1() {
		// TODO Auto-generated method stub
		
	}

}

