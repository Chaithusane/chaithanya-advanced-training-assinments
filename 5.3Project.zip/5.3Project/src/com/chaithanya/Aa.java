package com.chaithanya;

import java.util.Scanner;

public class Aa {
	static Scanner sc;
	public static void main(String[] args) {
		
		sc = new Scanner(System.in);
		System.out.println("Enter a aString");
		String inputString = sc.next();
		
		System.out.println();
		StringBuilder newString = new StringBuilder(inputString);
		System.out.println(newString);

		for(int index = 0 ; index<newString.length(); index++) {
			char charAt = newString.charAt(0);
			newString.deleteCharAt(0);
			newString.append(charAt);
			System.out.println(newString);
		}
		
		

	}

}

